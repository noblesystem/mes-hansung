﻿using hansung.Molder;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace hansung.page
{
    public partial class page1_2 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }

        
        protected void Ep_excel_Click(object sender, EventArgs e)
        {
            /*s
            string[] title = new string[] { "연번", "품목코드", "품목더존코드", "품목명", "규격", "매수", "규격면적", "안전재고량", "제조사", "정상/문제", "품목적요"};
            string[] query = new string[] { "order", "itemcode", "itemduzoncode", "itemname", "standard", "quantityincase", "specifiedarea", "safetystockquantity", "manufacturer", "status", "itembrief"};
            List<string> clnumber = new List<string>() { "order" };
            cm.exceldata(title, query, clnumber, "dataItem", "ItemList");
             */
        }

    }
}